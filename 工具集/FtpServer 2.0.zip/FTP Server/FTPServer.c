#define _WIN32_WINNT 0x501
#define DEFAULT_BUFLEN 4096
#define DEFAULT_PORT "9999"
#include <windows.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>

void Function1(char *Input) {
	char Buffer2S[140];
	strcpy(Buffer2S, Input);
}

void Function2(char *Input) {
	char Buffer2S[60];
	strcpy(Buffer2S, Input);
}

void Function3(char *Input) {
	char Buffer2S[2000];	
	strcpy(Buffer2S, Input);
}

void Function4(char *Input) {
	char Buffer2S[1000];
	strcpy(Buffer2S, Input);
}

// ÿ�ν��յ�һ���µ�������ô����һ���߳�,��������̺߳�����ִ�й���.
DWORD WINAPI ConnectionHandler(LPVOID CSocket) {
	int RecvBufLen = DEFAULT_BUFLEN;
	char *RecvBuf = malloc(DEFAULT_BUFLEN);
	char BigEmpty[1000];
	char *GdogBuf = malloc(1024);
	int Result, SendResult, i, k;
	memset(BigEmpty, 0, 1000);
	memset(RecvBuf, 0, DEFAULT_BUFLEN);
	SOCKET Client = (SOCKET)CSocket;

	// ���ӵ���������ʾ��Ϣ����ӡ��ʾ��Ϣ..
	SendResult = send( Client,"welcome to Windows FTP Server v2.0 !\n", 37,0);
	if (SendResult == SOCKET_ERROR) {
		// �����������ʧ����ر�����׽���
		closesocket(Client);
		return 1;
	}

	while (CSocket) {
		send(Client, "[FTP] # ", 8, 0);
		Result = recv(Client, RecvBuf, RecvBufLen, 0);
		if (Result > 0) {
			if (strncmp(RecvBuf, "help", 4) == 0) {
				const char ValidCommands[251] = "\n----------------------\nhelp\nstats [no]\nrtime [no]\nltime [no]\nSRUN [no]\nsend [yes]\ngmon [yes]\ngdog [no]\nKSTET [no]\nGTER [yes]\nHTER [yes]\nLTER [yes]\nKSTAN [no]\nEXIT\n ----------------------\n";
				SendResult = send( Client, ValidCommands, sizeof(ValidCommands), 0 );
			} else if (strncmp(RecvBuf, "stats ", 6) == 0) {
				char *StatBuf = malloc(120);
				memset(StatBuf, 0, 120);
				strncpy(StatBuf, RecvBuf, 120);
				SendResult = send( Client, "Connect FTP Server Success !\n", 29, 0 );
			} else if (strncmp(RecvBuf, "rtime ", 6) == 0) {
				char *RtimeBuf = malloc(120);
				memset(RtimeBuf, 0, 120);
				strncpy(RtimeBuf, RecvBuf, 120);
				SendResult = send( Client, "2020-01-01 01:01:01 \n", 21, 0 );
			} else if (strncmp(RecvBuf, "ltime ", 6) == 0) {
				char *LtimeBuf = malloc(120);
				memset(LtimeBuf, 0, 120);
				strncpy(LtimeBuf, RecvBuf, 120);
				SendResult = send( Client, "1997-12-12 12:12:12 \n", 21, 0 );
			} else if (strncmp(RecvBuf, "srun ", 5) == 0) {
				char *SrunBuf = malloc(120);
				memset(SrunBuf, 0, 120);
				strncpy(SrunBuf, RecvBuf, 120);
				SendResult = send( Client, "srun function Success \n", 24, 0 );
			} else if (strncmp(RecvBuf, "send ", 5) == 0) {
				// ����˵�����ʼ��һ��3000�ֽڵĻ�����
				char *TrunBuf = malloc(3000);
				memset(TrunBuf, 0, 3000);
				for (i = 5; i < RecvBufLen; i++) {
					if ((char)RecvBuf[i] == '.') {
						strncpy(TrunBuf, RecvBuf, 3000);
						// ��3000�ֽڵ����ݴ��ݸ���function3��������,��Ȼ�����ݻ��������.
						Function3(TrunBuf);
						break;
					}
				}
				memset(TrunBuf, 0, 3000);				
				SendResult = send( Client, "Data received successfully \n", 28, 0 );
			} else if (strncmp(RecvBuf, "gmon ", 5) == 0) {
				char GmonStatus[13] = "GMON STARTED\n";
				for (i = 5; i < RecvBufLen; i++) {
					if ((char)RecvBuf[i] == '/') {
						if (strlen(RecvBuf) > 3950) {
							Function3(RecvBuf);
						}
						break;
					}
				}				
				SendResult = send( Client, GmonStatus, sizeof(GmonStatus), 0 );
			} else if (strncmp(RecvBuf, "gdog ", 5) == 0) {				
				strncpy(GdogBuf, RecvBuf, 1024);
				SendResult = send( Client, "GDOG RUNNING\n", 13, 0 );
			} else if (strncmp(RecvBuf, "KSTET ", 6) == 0) {
				char *KstetBuf = malloc(100);
				strncpy(KstetBuf, RecvBuf, 100);
				memset(RecvBuf, 0, DEFAULT_BUFLEN);
				Function2(KstetBuf);
				SendResult = send( Client, "KSTET SUCCESSFUL\n", 17, 0 );
			} else if (strncmp(RecvBuf, "gter ", 5) == 0) {
				char *GterBuf = malloc(180);
				memset(GdogBuf, 0, 1024);
				strncpy(GterBuf, RecvBuf, 180);				
				memset(RecvBuf, 0, DEFAULT_BUFLEN);
				Function1(GterBuf);
				SendResult = send( Client, "GTER ON TRACK\n", 14, 0 );
			} else if (strncmp(RecvBuf, "hter ", 5) == 0) {
				char THBuf[3];
				memset(THBuf, 0, 3);
				char *HterBuf = malloc((DEFAULT_BUFLEN+1)/2);
				memset(HterBuf, 0, (DEFAULT_BUFLEN+1)/2);
				i = 6;
				k = 0;
				while ( (RecvBuf[i]) && (RecvBuf[i+1])) {
					memcpy(THBuf, (char *)RecvBuf+i, 2);
					unsigned long j = strtoul((char *)THBuf, NULL, 16);
					memset((char *)HterBuf + k, (byte)j, 1);
					i = i + 2;
					k++;
				} 
				Function4(HterBuf);
				memset(HterBuf, 0, (DEFAULT_BUFLEN+1)/2);
				SendResult = send( Client, "HTER RUNNING FINE\n", 18, 0 );
			} else if (strncmp(RecvBuf, "lter ", 5) == 0) {
				char *LterBuf = malloc(DEFAULT_BUFLEN);
				memset(LterBuf, 0, DEFAULT_BUFLEN);
				i = 0;
				while(RecvBuf[i]) {
					if ((byte)RecvBuf[i] > 0x7f) {
						LterBuf[i] = (byte)RecvBuf[i] - 0x7f;
					} else {
						LterBuf[i] = RecvBuf[i];
					}
					i++;
				}
				for (i = 5; i < DEFAULT_BUFLEN; i++) {
					if ((char)LterBuf[i] == '.') {					
						Function3(LterBuf);
						break;
					}
				}
				memset(LterBuf, 0, DEFAULT_BUFLEN);
				SendResult = send( Client, "LTER COMPLETE\n", 14, 0 );
			} else if (strncmp(RecvBuf, "kstan ", 6) == 0) {
				SendResult = send( Client, "KSTAN UNDERWAY\n", 15, 0 );
			} else if (strncmp(RecvBuf, "exit", 4) == 0) {           // �˳�ʱִ�����´���
				SendResult = send( Client, "good bye\n", 8, 0 );
				printf("Request: ----> Close\n");
				printf("-----------------------------------\n");
				closesocket(Client);
				return 0;
			}
			if (SendResult == SOCKET_ERROR) {                      // �����������,ִ������ķ���..
				printf("Request: ----> Error ID:%d\n", WSAGetLastError());
				printf("-----------------------------------\n");
				closesocket(Client);
				return 1;
			}
		} else if (Result == 0) {                                 // �������ӶϿ���ִ�д˲���...
			printf("Request: ----> Close\n");
			printf("-----------------------------------\n");
			closesocket(Client);
			return 0;			
		} else  {                                                // �����������,ִ������ķ���..
			printf("Request: ----> Error ID:%d\n", WSAGetLastError());
			printf("-----------------------------------\n");
			closesocket(Client);
			return 1;
		}
	}	
}

int main( int argc, char *argv[] ) {
	init();
	LoadLibraryA("msvcr71.dll");
	system("cls");
	printf("\n----------------------------------------------------------------------------\n");
	printf("\t\t Windows FTP Server version: 2.0 \t\t By: LyShark \n");
	printf("----------------------------------------------------------------------------\n");
	printf("INFO  Server is Running Port at 127.0.0.1:9999 . Press Ctrl+C to stop. \n");
	printf("----------------------------------------------------------------------------\n");
	
	WSADATA wsaData;
	SOCKET ListenSocket = INVALID_SOCKET,
	ClientSocket = INVALID_SOCKET;
	struct addrinfo *result = NULL, hints;
	int Result;
	struct sockaddr_in ClientAddress;
	int ClientAddressL = sizeof(ClientAddress);

	Result = WSAStartup(MAKEWORD(2,2), &wsaData);
	if (Result != 0) { return 1; }

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	Result = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
	if ( Result != 0 ) { WSACleanup(); return 1; }

	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {
		// �����׽���ʧ�ܺ�ִ���˳�����
		freeaddrinfo(result);
		WSACleanup();
		return 1;
	}

	Result = bind( ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (Result == SOCKET_ERROR) {
		// ���׽���ʧ�ܺ��˳�����
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}
	freeaddrinfo(result);
	Result = listen(ListenSocket, SOMAXCONN);
	if (Result == SOCKET_ERROR) {
		// ��������������,����ִ�йر��׽��ֲ��˳���������
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}		

	while(ListenSocket) {
		// ѭ���ȴ����������� Waiting for client connections...
		ClientSocket = accept(ListenSocket, (SOCKADDR*)&ClientAddress, &ClientAddressL);
		if (ClientSocket == INVALID_SOCKET) {
			closesocket(ListenSocket);
			WSACleanup();
			return 1;
		}
		// ����������IP��ַ��Ϣ
		printf("Request: ----> %s:%u\n", inet_ntoa(ClientAddress.sin_addr), htons(ClientAddress.sin_port));
		CreateThread(0,0,ConnectionHandler, (LPVOID)ClientSocket , 0,0);
	}
	closesocket(ListenSocket);
	WSACleanup();
	return 0;
}